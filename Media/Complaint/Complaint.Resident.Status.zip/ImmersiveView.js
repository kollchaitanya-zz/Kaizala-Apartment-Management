var KASFormPageNavigator = KASClient.UI.KASFormPageNavigator;
var KASFormPage = KASClient.UI.KASFormPage;
var KASQuestion = KASClient.KASQuestion;
var KASQuestionType = KASClient.KASQuestionType;

// Globals
var _pageNavigator = null; // type: KASFormPageNavigator
var _form = null; // type: KASForm
var _strings = null; // type: Dictionary<StringId: String>
var _properties = {}; 
var questionToAnswerMap ={};

var PROP_Category = "Complaint";
var PROP_STATUS = "Status";
var PROP_COMMENTS = "Comments";
var PROP_ID = "Complaint ID";
var _myFormResponses = {};

var PROP_STATUS_CLOSED = "Closed";
var PROP_STATUS_RESOLVED = "Resolved";
var PROP_STATUS_REOPEN = "Reopen";

var QUES_TICKETID = 0;
var QUES_STATUS = 1;
var QUES_COMMENTS = 2;
var QUES_ID = 3;


function onPageLoad() {
    // Remove any existing pages, if any
    if (_pageNavigator) {
        _pageNavigator.popAllPages();
    } else {
        _pageNavigator = new KASFormPageNavigator();
        var container = document.getElementById("container");
        KASClient.UI.addElement(_pageNavigator.getView(), container);
    }

    KASClient.App.getLocalizedStringsAsync(function (strings, error) {
        if (error != null) {
            showError("Error:getLocalizedStringsAsync:" + error);
            return;
        }
        _strings = strings;
        KASClient.Form.initFormAsync(function (form, error) {
            if (error != null) {
                showError("Error:initFormAsync:" + error);
                return;
            }
            _form = form;
            KASClient.Form.getMyFormResponsesAsync(function (responses, error) {
                if (error != null) {
                    handleError(error);
                    return;
                }
                _myFormResponses = responses[0];
                readProperties();
                showImmersivePage();
            });
        });
    });
}

function readProperties(){
    var prop = _form.properties;
    for (var i = 0; i < prop.length; i++) {
        _properties[prop[i].name] = prop[i].value;
    }
}


function showImmersivePage() {
    
    var page = new KASFormPage();
    page.navigationBar.title = _strings["strRequestStatus"];
    page.navigationBar.iconPath = "AppIcon.png";
    
    var mainView = KASClient.UI.getElement("div", {
        "display": "flex",
        "flex-direction": "column",
        "background-color": "white",
        "margin-bottom": "-4pt"
    });

    var table = KASClient.UI.getElement("table", { "border-collapse": "collapse", "overflow-wrap": "break-word", "word-wrap": "break-word", "word-break": "keep-all", "margin": "12px" });
    var row = table.insertRow(-1);
    
    var cell = row.insertCell(0);
    cell.innerHTML = "<b>" + _strings["strComplaintType"] + "</b>";
    cell = row.insertCell(1);
    cell.innerHTML = _properties[PROP_Category];

    row = table.insertRow(-1);
    cell = row.insertCell(0);
    cell.innerHTML = "<b>" + _strings["strStatus"] + "</b>";
    cell = row.insertCell(1);
    cell.innerHTML = _properties[PROP_STATUS];

    row = table.insertRow(-1);
    cell = row.insertCell(0);
    cell.innerHTML = "<b>" + _strings["strComments"] + "</b>";
    cell = row.insertCell(1);
    cell.innerHTML = _properties[PROP_COMMENTS];


    KASClient.UI.addElement(table,mainView);
    if(_myFormResponses)
    {
        KASClient.UI.addElement(addDetailsResponse(),mainView);

    } else if(_properties[PROP_STATUS] == PROP_STATUS_CLOSED || _properties[PROP_STATUS] == PROP_STATUS_RESOLVED)
    {

        KASClient.UI.addElement(inflateCommentsBox(QUES_COMMENTS), mainView);
    
        var buttonContainer = KASClient.UI.getElement("div", {
            "position": "fixed",
            "bottom": "0px",
            "left": "0px",
            "width": "100%",
            "padding": "15px",
            "z-index": "1",
            "background-color": "white",
            "box-shadow": "0px -10px 20px white"
        });
    
        var button = KASClient.UI.getButton(_strings["strReopenTicket"], submitReopenRequest, {
            "height": "50px",
            "width": "calc(100% - 30px)",
            "line-height": "50px",
            "text-align": "center",
            "color": "white",
            "font-size": "16px",
            "font-weight": "600",
            "border-radius": "2px"
        });
        button.style.pointerEvents = 'none';
        button.style.backgroundColor = "rgba(80, 215, 137,.5)";
        button.id = "submit";
    
        KASClient.UI.addElement(button, buttonContainer);
        page.bottomBar.elements = [buttonContainer];
    
    }

    page.moduleContainer.addViewWithFullWidth(mainView);
    page.moduleContainer.backgroundColor = "white";
    page.moduleContainer.getView().style.marginBottom = "100px";

    _pageNavigator.pushPage(page);

}

function invalidateFooter(){
    var button = document.getElementById("submit");
    if(!questionToAnswerMap[QUES_COMMENTS] || questionToAnswerMap[QUES_COMMENTS].trim().length == 0)
    {
        button.style.pointerEvents = 'none';
        button.style.backgroundColor = "rgba(80, 215, 137,.5)";
    } else {
        button.style.pointerEvents = 'auto';
        button.style.backgroundColor = "rgb(80, 215, 137)";
    }
}

function submitReopenRequest(){
    questionToAnswerMap[QUES_TICKETID] = _properties[PROP_Category];
    questionToAnswerMap[QUES_STATUS] = PROP_STATUS_REOPEN;
    questionToAnswerMap[QUES_ID] = _properties[PROP_ID];
    KASClient.Form.sumbitFormResponse(questionToAnswerMap, null, false, false);
}

function addDetailsResponse()
{
    var detailsResponseDiv = KASClient.UI.getElement("div",{"padding": "16px","padding-top": "0px"});
    detailsResponseDiv.className = "section";
    KASClient.UI.addElement(inflateTitle(_strings["strReopenDetails"]), detailsResponseDiv);
    var responseDiv = inflateTitle(_myFormResponses.questionToAnswerMap[QUES_COMMENTS]);
    responseDiv.style.fontWeight = "normal";
    KASClient.UI.addElement(responseDiv, detailsResponseDiv);
    return detailsResponseDiv;

}


function inflateCommentsBox(index) {
    
        var textQuestionDiv = KASClient.UI.getElement("div",{"padding": "16px","padding-top": "0px"});
        textQuestionDiv.id = index;
        textQuestionDiv.className = "section";

        var textQuestionInput;
        textQuestionInput = KASClient.UI.getContentEditableSpan("", _strings["strTapToEnter"], { "width": "auto" }, function () {
            questionToAnswerMap[index] = event.target.innerText;
            invalidateFooter();

        });

        textQuestionInput.className = "comment-input";
        KASClient.UI.addElement(inflateTitle(_strings["strAdditionDetails"]), textQuestionDiv);
        KASClient.UI.addElement(textQuestionInput, textQuestionDiv);
        return textQuestionDiv;
}

function inflateTitle(title) {
    var questionTitle = KASClient.UI.getElement("div", { "font-weight": "bold" });
    questionTitle.className = "question-title";
    questionTitle.innerText = title;
    return questionTitle;
}

